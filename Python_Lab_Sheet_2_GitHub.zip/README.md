# Python Lab Sheet 2 - GitHub

Q01.py-Q33.py contain all solutions. Challenge_Merit_List.py exports student_merit_list.xlsx.

Install: `pip install pandas openpyxl`
