import numpy as np

arr = np.arange(7, 101, 7)
print("Multiples of 7:", arr)
print("Length:", len(arr))
