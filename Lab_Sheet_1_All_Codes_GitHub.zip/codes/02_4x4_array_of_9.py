import numpy as np

arr = np.full((4, 4), 9)
print(arr)
