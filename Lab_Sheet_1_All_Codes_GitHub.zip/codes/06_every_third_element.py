import numpy as np

arr = np.arange(1, 13)
result = arr[1::3]

print("Array:", arr)
print("Every third element from index 1:", result)
