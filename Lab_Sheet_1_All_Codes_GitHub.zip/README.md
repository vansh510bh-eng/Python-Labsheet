# Lab Sheet 1 – Python Libraries and Applications

**Course:** BCA  
**Topic:** NumPy / Python  
**Lab Sheet:** 1 – Array Creation & Basics

## Contents

This repository contains solutions for all 28 questions from Lab Sheet 1.

### Folder structure

```text
Lab_Sheet_1_GitHub/
├── codes/
│   ├── 01_multiples_of_7.py
│   ├── 02_4x4_array_of_9.py
│   ├── ...
│   └── 28_random_deck_hand.py
├── Lab_Sheet_1.pdf
├── README.md
└── requirements.txt
```

## How to run

Install NumPy:

```bash
pip install -r requirements.txt
```

Then run any solution, for example:

```bash
python codes/01_multiples_of_7.py
```

Some programs create output files such as `random_array.csv` or `three_arrays.npz` in the current folder.
